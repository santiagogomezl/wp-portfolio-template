<?php
define('SMTP_SERVER', 'localhost');
define('SMTP_PORT', 25);
define('SMTP_USERNAME', 'contact@santiagogomezl.com');
define('SMTP_PASSWORD', 'winnyP00');
?>